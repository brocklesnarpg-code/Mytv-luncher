package com.example.glassylauncher;

import org.json.JSONException;
import org.json.JSONObject;

/** Plain weather snapshot, serialisable to JSON for the offline cache. */
public final class WeatherData {
    public String city = "";
    public double lat, lon;
    public double temp, feels, high, low, wind, uv;
    public int humidity, code;
    public boolean isDay = true;
    public String sunrise = "--:--", sunset = "--:--";
    public long updatedMs;

    public String toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("city", city); o.put("lat", lat); o.put("lon", lon);
        o.put("temp", temp); o.put("feels", feels); o.put("high", high); o.put("low", low);
        o.put("wind", wind); o.put("uv", uv); o.put("humidity", humidity); o.put("code", code);
        o.put("isDay", isDay); o.put("sunrise", sunrise); o.put("sunset", sunset);
        o.put("updated", updatedMs);
        return o.toString();
    }

    public static WeatherData fromJson(String s) {
        try {
            JSONObject o = new JSONObject(s);
            WeatherData w = new WeatherData();
            w.city = o.optString("city", ""); w.lat = o.optDouble("lat"); w.lon = o.optDouble("lon");
            w.temp = o.getDouble("temp"); w.feels = o.optDouble("feels", w.temp);
            w.high = o.optDouble("high", w.temp); w.low = o.optDouble("low", w.temp);
            w.wind = o.optDouble("wind", 0); w.uv = o.optDouble("uv", 0);
            w.humidity = o.optInt("humidity"); w.code = o.optInt("code");
            w.isDay = o.optBoolean("isDay", true);
            w.sunrise = o.optString("sunrise", "--:--"); w.sunset = o.optString("sunset", "--:--");
            w.updatedMs = o.optLong("updated");
            return w;
        } catch (Exception e) {
            return null;
        }
    }
}
