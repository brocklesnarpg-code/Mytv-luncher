package com.example.glassylauncher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Wallpaper catalogue: built-in generated wallpapers, one picked custom image, and any
 * image dropped into the app's "wallpapers" folder (no storage permission needed).
 */
public final class WallpaperStore {

    public static final String CUSTOM_NAME = "My picture";

    public static final class Item {
        public final String name;
        public final File file;     // null for built-in
        public final int builtin;   // index into PALETTES, -1 for files
        Item(String name, File file, int builtin) { this.name = name; this.file = file; this.builtin = builtin; }
    }

    private static final String[] NAMES = {"Aurora", "Sunset", "Ocean", "Midnight", "Forest", "Rose"};
    // base0, base1, base2, blob0, blob1, blob2
    private static final int[][] PALETTES = {
            {0xFF0B1B3A, 0xFF1B4F72, 0xFF117A65, 0xFF2ECC71, 0xFF3498DB, 0xFF8E44AD},
            {0xFF2C1654, 0xFFB5446E, 0xFFF28C38, 0xFFFF6B6B, 0xFFFFB86B, 0xFF7B4DFF},
            {0xFF021B2D, 0xFF05507A, 0xFF1AA6B7, 0xFF00D2FF, 0xFF3A7BD5, 0xFF00B4DB},
            {0xFF05060F, 0xFF141A3A, 0xFF2B2F6B, 0xFF5B6CFF, 0xFF9B59FF, 0xFF2C3E9E},
            {0xFF04140D, 0xFF0F4D37, 0xFF3C8D5A, 0xFF2ECC71, 0xFFA3E635, 0xFF16A085},
            {0xFF2A0A1F, 0xFF8E2C5B, 0xFFE8869B, 0xFFFF5E9C, 0xFFFFA8C5, 0xFFB04BFF},
    };

    private final Context ctx;
    private final SharedPreferences sp;
    private final File customFile;
    private final File folder;

    public WallpaperStore(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        customFile = new File(ctx.getFilesDir(), "wallpaper_custom.jpg");
        File f = ctx.getExternalFilesDir("wallpapers");
        if (f != null) f.mkdirs();
        folder = f;
    }

    public String folderPath() { return folder == null ? "(unavailable)" : folder.getAbsolutePath(); }

    public List<Item> items() {
        List<Item> l = new ArrayList<>();
        for (int i = 0; i < NAMES.length; i++) l.add(new Item(NAMES[i], null, i));
        if (customFile.exists()) l.add(new Item(CUSTOM_NAME, customFile, -1));
        if (folder != null) {
            File[] fs = folder.listFiles();
            if (fs != null) {
                Arrays.sort(fs);
                for (File f : fs) {
                    String n = f.getName().toLowerCase(Locale.ROOT);
                    if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp")) {
                        l.add(new Item(f.getName().replaceAll("\\.[^.]+$", ""), f, -1));
                    }
                }
            }
        }
        return l;
    }

    public Item current() {
        List<Item> l = items();
        String n = sp.getString("wallpaper", NAMES[0]);
        for (Item i : l) if (i.name.equals(n)) return i;
        return l.get(0);
    }

    public void select(String name) { sp.edit().putString("wallpaper", name).apply(); }

    /** Moves the selection by dir (-1/+1) and returns the new current item. */
    public Item step(int dir) {
        List<Item> l = items();
        String n = current().name;
        int idx = 0;
        for (int i = 0; i < l.size(); i++) if (l.get(i).name.equals(n)) idx = i;
        Item next = l.get(((idx + dir) % l.size() + l.size()) % l.size());
        select(next.name);
        return next;
    }

    /** Blocking – call off the main thread. */
    public Bitmap load(Item it) {
        try {
            if (it.file == null) return renderBuiltin(it.builtin, 1280, 720);
            return decode(it.file.getAbsolutePath());
        } catch (Throwable t) {
            return null;
        }
    }

    /** Blocking – copies a user-picked image into private storage, down-scaled. */
    public boolean importFromUri(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = ctx.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            o.inSampleSize = sampleFor(o.outWidth, o.outHeight);
            o.inJustDecodeBounds = false;
            Bitmap b;
            try (InputStream in = ctx.getContentResolver().openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o); }
            if (b == null) return false;
            try (FileOutputStream out = new FileOutputStream(customFile)) { b.compress(Bitmap.CompressFormat.JPEG, 92, out); }
            b.recycle();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static int sampleFor(int w, int h) {
        int s = 1;
        while (w / s > 2560 && h / s > 1440) s *= 2;
        return s;
    }

    private static Bitmap decode(String path) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, o);
        o.inSampleSize = sampleFor(o.outWidth, o.outHeight);
        o.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(path, o);
    }

    private static Bitmap renderBuiltin(int i, int w, int h) {
        int[] pal = PALETTES[i];
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, new int[]{pal[0], pal[1], pal[2]},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        float[][] blobs = {{0.18f, 0.25f, 0.55f}, {0.80f, 0.35f, 0.50f}, {0.50f, 0.95f, 0.60f}};
        for (int k = 0; k < 3; k++) {
            int col = pal[3 + k] & 0x00FFFFFF;
            float cx = w * blobs[k][0], cy = h * blobs[k][1], r = Math.max(w, h) * blobs[k][2];
            p.setShader(new RadialGradient(cx, cy, r, col | 0x99000000, col, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
        }
        p.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.75f, 0x00000000, 0xAA000000,
                Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        return b;
    }
}
