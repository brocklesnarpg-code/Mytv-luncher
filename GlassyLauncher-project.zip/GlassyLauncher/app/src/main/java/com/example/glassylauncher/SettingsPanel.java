package com.example.glassylauncher;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Right-hand glass settings drawer, fully D-pad driven (LEFT/RIGHT changes values). */
final class SettingsPanel extends FrameLayout {

    interface Host {
        String wallpaperName();
        void stepWallpaper(int dir);
        void pickImage();
        boolean widgetEnabled();
        void toggleWidget();
        String locationLabel();
        void useAutoLocation();
        void changeCity();
        void refreshWeather();
        void openHomeSettings();
        void panelClosed();
    }

    private interface Step { void step(int dir); }

    private final Host host;
    private final float u;
    private final LinearLayout col;
    private boolean open;
    private TextView wpVal, widgetVal, locVal;
    private LinearLayout firstRow;

    SettingsPanel(Context ctx, Host host, float u) {
        super(ctx);
        this.host = host;
        this.u = u;
        setVisibility(GONE);
        setClickable(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2111419);
        float r = 2.4f * u;
        bg.setCornerRadii(new float[]{r, r, 0, 0, 0, 0, r, r});
        setBackground(bg);
        setElevation(4 * u);

        col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (2.2f * u);
        col.setPadding(pad, pad, pad, pad);
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextView title = label("Settings", 2.6f, 0xFFFFFFFF, Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, (int) (1.2f * u));
        col.addView(title);

        firstRow = row("Wallpaper", null, dir -> host.stepWallpaper(dir));
        wpVal = (TextView) firstRow.getChildAt(1);
        row("Choose picture\u2026", host::pickImage, null);
        LinearLayout w = row("Weather widget", host::toggleWidget, null);
        widgetVal = (TextView) w.getChildAt(1);
        LinearLayout l = row("Location", host::useAutoLocation, null);
        locVal = (TextView) l.getChildAt(1);
        row("Change city\u2026", () -> { close(); host.changeCity(); }, null);
        row("Refresh weather now", host::refreshWeather, null);
        row("Set as default home\u2026", host::openHomeSettings, null);
        row("Close", this::close, null);
    }

    boolean isOpen() { return open; }

    void refresh() {
        wpVal.setText("\u2039  " + host.wallpaperName() + "  \u203a");
        widgetVal.setText(host.widgetEnabled() ? "On" : "Off");
        locVal.setText(host.locationLabel());
    }

    void open() {
        if (open) return;
        open = true;
        refresh();
        setVisibility(VISIBLE);
        setTranslationX(getLayoutParams().width);
        animate().translationX(0).setDuration(220).start();
        firstRow.requestFocus();
    }

    void close() {
        if (!open) return;
        open = false;
        animate().translationX(getWidth()).setDuration(200).withEndAction(() -> setVisibility(GONE)).start();
        host.panelClosed();
    }

    private TextView label(String s, float sizeU, int color, Typeface tf) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(color);
        t.setTypeface(tf);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private LinearLayout row(String title, final Runnable ok, final Step step) {
        final LinearLayout r = new LinearLayout(getContext());
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setFocusable(true);
        r.setClickable(true);
        r.setPadding((int) (1.6f * u), (int) (1.2f * u), (int) (1.6f * u), (int) (1.2f * u));
        final GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(1.2f * u);
        bg.setColor(0x14FFFFFF);
        r.setBackground(bg);

        TextView t = label(title, 1.7f, 0xFFFFFFFF, Typeface.DEFAULT);
        r.addView(t, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        TextView v = label("", 1.5f, 0xA6FFFFFF, Typeface.DEFAULT);
        r.addView(v);

        r.setOnFocusChangeListener((x, f) -> {
            bg.setColor(f ? 0x55FFFFFF : 0x14FFFFFF);
            x.animate().scaleX(f ? 1.03f : 1f).scaleY(f ? 1.03f : 1f).setDuration(140).start();
        });
        r.setOnClickListener(x -> {
            if (step != null) step.step(1);
            else if (ok != null) ok.run();
            refresh();
        });
        r.setOnKeyListener((x, code, e) -> {
            if (e.getAction() == KeyEvent.ACTION_DOWN
                    && (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                if (step != null) { step.step(code == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1); refresh(); }
                return true; // never let focus leave the panel sideways
            }
            return false;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (0.6f * u);
        col.addView(r, lp);
        return r;
    }
}
